
  # Aplicativo de Gestão Médica (Copy)

  This is a code bundle for Aplicativo de Gestão Médica (Copy). The original project is available at https://www.figma.com/design/PuxHiW7c2vqrm9EnDJxQnz/Aplicativo-de-Gest%C3%A3o-M%C3%A9dica--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  